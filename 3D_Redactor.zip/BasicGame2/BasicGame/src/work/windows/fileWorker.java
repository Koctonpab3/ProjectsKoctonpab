/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package work.windows;

/**
 *
 * @author Uzver
 */
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.awt.image.ImageObserver;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import javax.imageio.ImageIO;



/**
 *
 * @author KocTonpaB
 */
public class fileWorker {
         String FileData,FileName="";
         FileInputStream File1;
         FileOutputStream File2;
         String[][] OutLayer=new String[20][20];
         String[][] OutPrjCyl=new String[64][20];
         String[][] OutPrjSym=new String[10][20];
         String[][][] OutPrjAsm=new String[20][20][20];
 
public String[][] imgReadLayer(String fileName,String param){
String[][] Out= new String[64][20];
Graphics g = null;
 ImageObserver IobSer = null;
 BufferedImage imgDraw;//,imgK;
imgDraw =loadImage(fileName);
int stX=0,stY=0,xMax=0;
if (param.equalsIgnoreCase("Sym")){xMax=10;}
if (param.equalsIgnoreCase("Cyl")){xMax=64;}
if (param.equalsIgnoreCase("Asm")){xMax=20;}

stX=imgDraw.getWidth()/xMax;
stY=imgDraw.getHeight()/20;

for(int x=0;x<xMax;x++){
    for(int y=0;y<20;y++){
        int[] colAvrg=new int[3];
        for(int i=0;i<3;i++)colAvrg[i]=0;
           for(int i=0;i<stX;i++){
            for(int j=0;j<stY;j++){
            colAvrg[0]=colAvrg[0]+ aToRgb(imgDraw.getRGB(x*stX+i, y*stY+j))[0];
            colAvrg[1]=colAvrg[1]+ aToRgb(imgDraw.getRGB(x*stX+i, y*stY+j))[1];
            colAvrg[2]=colAvrg[2]+ aToRgb(imgDraw.getRGB(x*stX+i, y*stY+j))[2];
            }}
           colAvrg[0]=colAvrg[0]/(stX*stY);
           colAvrg[1]=colAvrg[1]/(stX*stY);
           colAvrg[2]=colAvrg[2]/(stX*stY);
           
           Out[x][y]=(iToScol(colAvrg[0])+iToScol(colAvrg[1])+iToScol(colAvrg[2]));
    }
}

return Out;
}    
public String iToScol(int col){
String out="";
if(col<128)out="0";
if(col>=128)out="1";
return out;
}

public int[] aToRgb(int color){
    int[] out=new int[4];
          //прозрачность
         out[3] = color >>> 24;
            //Red
         out[0] = ((color << 8) >>> 24);
            //Green
         out[1] = ((color << 16) >>> 24);
            //Blue
         out[2] = ((color << 24) >>> 24);
         
    return out;
}

public static BufferedImage loadImage(String ref) {
           BufferedImage bimg = null;
           try {

               bimg = ImageIO.read(new File(ref));
           } catch (Exception e) {
           }
           return bimg;
       }
  
public String[][] fileReadLayer(String fileName){
String[][] Out= new String[64][20];
StringBuilder sb = new StringBuilder();
try {
BufferedReader in = new BufferedReader(new FileReader( new File(fileName).getAbsoluteFile()));
try {
  
String s;
int y=0;
while ((s = in.readLine()) != null) {
   for(int x=0;x<s.length();x++)if(y<20)Out[x][y]=ch2n(s.charAt(x));
y++;
} 

    } finally {
     in.close();
    }
    } catch(IOException e) {
    throw new RuntimeException(e);
} 
return Out; 
}

public String[][][] fileReadProject(String fileName){
String[][][] Out= new String[20][20][20];
//StringBuilder sb = new StringBuilder();
try {
BufferedReader in = new BufferedReader(new FileReader( new File(fileName).getAbsoluteFile()));
try {
  
String s;
int y=0,z=0;
 if (in.readLine().equalsIgnoreCase("Asm")){
while ((s = in.readLine()) != null) {
   for(int x=0;x<s.length();x++)if(y<20 & z<20)Out[x][y][z]=ch2n(s.charAt(x));
y++;if(y>19){y=0;z++;}

} }

    } finally {
     in.close();
    }
    } catch(IOException e) {
    throw new RuntimeException(e);
} 
return Out; 
}

public void fileSaveProject(char[][][] inMas,String fileName){
       
       try {
PrintWriter out = new PrintWriter(new File(fileName).getAbsoluteFile());
try {
        out.print("Asm");
        out.println();
    for(int z=0;z<20;z++){
     for(int y=0;y<20;y++){
        String data="";
        for(int x=0;x<20;x++){
            data=data+(inMas[x][y][z]);
        }
        out.print(data);
        out.println();
     }
     }
     out.print("End");
        out.println();

    } finally {
    out.close();
    }
    } catch(IOException e) {
    throw new RuntimeException(e);
} 
}     

public void fileSaveLayer(String[][] inMas,String fileName){
       
       try {
PrintWriter out = new PrintWriter(new File(fileName).getAbsoluteFile());
try {
    
     for(int y=0;y<20;y++){
        String data="";
        for(int x=0;x<20;x++){
            data=data+n2ch(inMas[x][y]);
        }
        out.print(data);
        out.println();
     }
     out.print("End");
        out.println();

    } finally {
    out.close();
    }
    } catch(IOException e) {
    throw new RuntimeException(e);
} 
}     
         
   
/// СОБСТВЕННАЯ ФУНКЦИЯ ПРЕОБРАЗОВАНИЯ СТРОКИ В ЧИСЛО 
 public static int strToInt(String Str)
{
int Num=((int)Str.charAt(Str.length()-1)-48),ink=1;
if(Str.length()>1)
for(int i=Str.length()-2;i>-1;i--){
Num+=(((int)Str.charAt(i))-48)*Math.pow(10,ink);//берется
ink++;
}
return Num;
}
public String ch2n(char ch){
    String out="";
    
if (ch=='0') out="000";//установка белого
if (ch=='B') out="001";
if (ch=='G') out="010";
if (ch=='R') out="100";
if (ch=='C') out="011";
if (ch=='Y') out="110";
if (ch=='M') out="101";
if (ch=='W') out="111";
    return out;
}    
public char n2ch(String ch){
    char out=' ';
if (ch.equalsIgnoreCase("000")) out='0';//установка белого
if (ch.equalsIgnoreCase("001")) out='B';
if (ch.equalsIgnoreCase("010")) out='G';
if (ch.equalsIgnoreCase("100")) out='R';
if (ch.equalsIgnoreCase("011")) out='C';
if (ch.equalsIgnoreCase("110")) out='Y';
if (ch.equalsIgnoreCase("101")) out='M';
if (ch.equalsIgnoreCase("111")) out='W';
    return out;
}    
    
}
