/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package intrerfaces.visedit;

import java.awt.Graphics;

/**
 *
 * @author Uzver
 */
public interface poleImg {
    void draw(Graphics g);
    void click(int x, int y, String color,String mode,String color2);
    void setX(int X);
    void setY(int Y);
    void setXvox(int Xvox);
    void setYvox(int Yvox);
    void setWidth(int W);
    void setHeight(int H);
    void setPole(String[][] Mas);
    void setVoxel(int x,int y,String color);
    void undo();
    void redo();    
    int getX();
    int getY();
    int getXvox();
    int getYvox();
    int getWidth();
    int getHeight();
    String getVoxel(int x,int y);
    String[][] getPole(); 
}
