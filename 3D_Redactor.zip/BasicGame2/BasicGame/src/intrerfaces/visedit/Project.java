/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package intrerfaces.visedit;

/**
 *
 * @author Admin
 */
public interface Project {
void setVoxel(int x,int y,int z, String color);
String getVoxel(int x,int y,int z);
String getType();
int getWidth();
int getHeight();
int getDepth();
void setType(String type);
String[][] getLayer(int nl);
void setLayer(String[][] Mas, int nl);
}
