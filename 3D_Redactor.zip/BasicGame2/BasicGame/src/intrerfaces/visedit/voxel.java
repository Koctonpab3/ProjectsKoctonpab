/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package intrerfaces.visedit;

import java.awt.Graphics;

/**
 *
 * @author Uzver
 */
public interface voxel {
    void draw(Graphics g);
    String click(int x, int y,String color);
    void setX(int X);
    void setY(int Y);
    void setXpos(int Xpos);
    void setYpos(int Ypos);
    void setColor(String color);
    void setWidth(int W);
    void setHeight(int H);
    int getXpos();
    int getYpos();
    int getX();
    int getY();    
    String getColor();
    int getWidth();
    int getHeight();
}
