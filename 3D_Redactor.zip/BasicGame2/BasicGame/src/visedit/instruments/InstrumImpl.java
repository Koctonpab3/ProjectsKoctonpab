/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package visedit.instruments;

import intrerfaces.visedit.Instrum;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.awt.image.ImageObserver;
import java.io.File;
import javax.imageio.ImageIO;
/**
 *
 * @author Uzver
 */
public class InstrumImpl implements Instrum{
   int x,y,width=100,height=200,yp=100;
   String cur1="pen";
   
      ImageObserver IobSer;
   BufferedImage img1 = null;
   BufferedImage img2 = null;
   BufferedImage img3 = null;
   BufferedImage img4 = null;
   BufferedImage img5 = null;
   BufferedImage img6 = null;
   BufferedImage imgChoose = null;
   
 EdInstrumImpl Instr1= new EdInstrumImpl(614,yp,"pen");
 EdInstrumImpl Instr2= new EdInstrumImpl(644,yp,"brush");
 EdInstrumImpl Instr3= new EdInstrumImpl(614,yp+30,"line");
 EdInstrumImpl Instr4= new EdInstrumImpl(644,yp+30,"circle");
 EdInstrumImpl Instr5= new EdInstrumImpl(614,yp+60,"rect");
 EdInstrumImpl Instr6= new EdInstrumImpl(644,yp+60,"copy");



    public InstrumImpl(int x,int y){
   this.x=x;
   this.y=y;
   if(img1==null) img1 =loadImage("resources\\buttons\\pencil.jpg");
   if(img2==null) img2 =loadImage("resources\\buttons\\brush.jpg");
   if(img3==null) img3 =loadImage("resources\\buttons\\line.jpg");
   if(img4==null) img4 =loadImage("resources\\buttons\\circle.jpg");
   if(img5==null) img5 =loadImage("resources\\buttons\\rectangle.jpg");
   if(img6==null) img6 =loadImage("resources\\buttons\\allocation.jpg");
   
   }

     public static BufferedImage loadImage(String ref) {
           BufferedImage bimg = null;
           try {

               bimg = ImageIO.read(new File(ref));
           } catch (Exception e) {
           }
           return bimg;
       }
    
    public String click(int x, int y,int Mbutton) {
        String colPress="";

      if ((x>this.getX() & x<(this.getX()+this.getWidth())) &
              (y>this.getY() & y<(this.getY()+this.getHeight()))){
          int flag=0;
        if(!"".equals(Instr1.click(x, y))){colPress=Instr1.click(x, y);flag=1;}
        if(!"".equals(Instr2.click(x, y))){colPress=Instr2.click(x, y);flag=1;}
        if(!"".equals(Instr3.click(x, y))){colPress=Instr3.click(x, y);flag=1;}
        if(!"".equals(Instr4.click(x, y))){colPress=Instr4.click(x, y);flag=1;}
        if(!"".equals(Instr5.click(x, y))){colPress=Instr5.click(x, y);flag=1;}
        if(!"".equals(Instr6.click(x, y))){colPress=Instr6.click(x, y);flag=1;}

        if (flag==1){cur1=colPress;flag=0;}
      }
            return cur1;}

    public void setX(int X) { this.x=X;
    Instr1.setX(X);
    Instr2.setX(X+30);
    Instr3.setX(X);
    Instr4.setX(X+30);
    Instr5.setX(X);
    Instr6.setX(X+30);

    }
    public void setY(int Y) { this.y=Y; }
    public void setWidth(int W) {this.width=W; }
    public void setHeight(int H) {this.height=H; }
    public int getX() { return this.x; }
    public int getY() { return this.y; }
    public int getWidth(){return this.width; }
    public int getHeight(){return this.height;}
    public String getCur1() { return this.cur1; }

    public void draw(Graphics g) {
g.clearRect(this.x,yp+125,50,26);//очистка
g.setColor(Color.white);//установка белого
g.fillRect(this.x,yp+125,50,26); //рисуем фон
if (cur1.equalsIgnoreCase("pen")) imgChoose=img1;//установка белого
if (cur1.equalsIgnoreCase("brush")) imgChoose=img2;
if (cur1.equalsIgnoreCase("line")) imgChoose=img3;
if (cur1.equalsIgnoreCase("circle")) imgChoose=img4;
if (cur1.equalsIgnoreCase("rect")) imgChoose=img5;
if (cur1.equalsIgnoreCase("copy")) imgChoose=img6;
 
g.drawImage(imgChoose, this.x, yp+135,26,26, IobSer);
//g.fillRect(this.x,yp+135,26,26); //рисуем фон
g.setColor(Color.DARK_GRAY); //установка серого
g.drawRect(this.x,yp+135,26,26);// рисуем окантовку}


    Instr1.draw(g);
    Instr2.draw(g);
    Instr3.draw(g);
    Instr4.draw(g);
    Instr5.draw(g);
    Instr6.draw(g);


    }
}
