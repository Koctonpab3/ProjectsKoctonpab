/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package visedit.instruments;

import intrerfaces.visedit.EdInstrum;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.awt.image.ImageObserver;
import java.io.File;
import javax.imageio.ImageIO;
import static visedit.instruments.InstrumImpl.loadImage;

/**
 *
 * @author Uzver
 */
public class EdInstrumImpl implements EdInstrum{
    int x,y,width=26,height=26;
    String instr="pen";
       ImageObserver IobSer;
   BufferedImage img1 = null;
   BufferedImage img2 = null;
   BufferedImage img3 = null;
   BufferedImage img4 = null;
   BufferedImage img5 = null;
   BufferedImage img6 = null;
   BufferedImage imgChoose = null;

    public EdInstrumImpl(int x,int y,String instr){
   this.x=x;
   this.y=y;
   this.instr=instr;
   if(img1==null) img1 =loadImage("resources\\buttons\\pencil.jpg");
   if(img2==null) img2 =loadImage("resources\\buttons\\brush.jpg");
   if(img3==null) img3 =loadImage("resources\\buttons\\line.jpg");
   if(img4==null) img4 =loadImage("resources\\buttons\\circle.jpg");
   if(img5==null) img5 =loadImage("resources\\buttons\\rectangle.jpg");
   if(img6==null) img6 =loadImage("resources\\buttons\\allocation.jpg");
   }

     public static BufferedImage loadImage(String ref) {
           BufferedImage bimg = null;
           try {

               bimg = ImageIO.read(new File(ref));
           } catch (Exception e) {
           }
           return bimg;
       }
    
    public String click(int x, int y) {
        String outp="";
        if (x>this.x & x<this.width+this.x & y>this.y & y<this.height+this.y )
        outp=this.instr;
            return outp;}

    public void setX(int X) { this.x=X;}
    public void setY(int Y) { this.y=Y; }
    public void setWidth(int W) {this.width=W; }
    public void setHeight(int H) {this.height=H; }
    public int getX() { return this.x; }
    public int getY() { return this.y; }
    public int getWidth(){return this.width; }
    public int getHeight(){return this.height;}

    public void draw(Graphics g) {
g.clearRect(this.x, this.y, this.width, this.height);//очистка
g.setColor(Color.white);//установка белого
g.fillRect(this.x,this.y, this.width, this.height); //рисуем фон
if (this.instr.equalsIgnoreCase("pen")) imgChoose=img1;//установка белого
if (this.instr.equalsIgnoreCase("brush"))imgChoose=img2;
if (this.instr.equalsIgnoreCase("line")) imgChoose=img3;
if (this.instr.equalsIgnoreCase("rect")) imgChoose=img5;
if (this.instr.equalsIgnoreCase("circle")) imgChoose=img4;
if (this.instr.equalsIgnoreCase("copy")) imgChoose=img6;


 
g.drawImage(imgChoose, this.x, this.y,this.width,this.height, IobSer);

//g.fillRect(this.x+3,this.y+3, this.width-5, this.height-5); //рисуем фон
g.setColor(Color.DARK_GRAY); //установка серого
g.drawRect(this.x,this.y, this.width, this.height);// рисуем окантовку}
    }
    public void setInstr(String instr) {this.instr=instr; }
    public String getInstr() {return this.instr;}
}
