/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package visedit.windows;

import java.awt.Color;
import java.awt.Graphics;
import visedit.elements.ButtonImpl;

/**
 *
 * @author Uzver
 */
public class aboutWindow {
     int x,y,width,height,enable,movie,dx,dy,flag;
    String title="",text="";
    public ButtonImpl clsWindw = new ButtonImpl(0,0,15,10,
            "resources\\bttn.jpg","resources\\bttn.jpg"); 
    public ButtonImpl okBtn = new ButtonImpl(0,0,30,20,
            "resources\\bttn.jpg","resources\\bttn.jpg"); 
   
    public aboutWindow(int x1, int y1, int w, int h,int en){
   this.x=x1;
   this.y=y1;
   this.width=w;
   this.height=h;
   this.title="О программе";
   this.enable=en;
   this.movie=0;
   this.flag=0;
   clsWindw.setX(this.x+this.width-clsWindw.getWidth()-2);
   clsWindw.setY(this.y+2);
   okBtn.setX(this.x+this.width/2-okBtn.getWidth()/2);
   okBtn.setY(this.y+this.width - okBtn.getHeight()-5);
   
}
    public void movie(int x, int y){
        
if(this.movie==1){
    this.x=x-dx;//-(x-this.x);
    this.y=y-dy;//-(y-this.y);
   okBtn.setX(this.x+this.width/2-okBtn.getWidth()/2);
   okBtn.setY(this.y+this.width - okBtn.getHeight()-5);
    clsWindw.setX(this.x+this.width-clsWindw.getWidth()-2);
    clsWindw.setY(this.y+2);
        }
    }
    
     public char click(int x, int y) { 
         char outp='f';
        if((x>=this.x & x<=(this.x+this.width))&
                y>=this.y & y<=(this.y+this.height)& this.enable==1){
        if (clsWindw.click(x, y).equalsIgnoreCase("true")){this.enable=0;outp='c';}
        this.movie=0;
        if((x>=this.x & x<=(this.x+this.width))&
                (y>=this.y & y<=(this.y+4+clsWindw.getHeight()))){this.movie=1;
    this.dx=(x-this.x);
    this.dy=(y-this.y);
    this.flag++;
    if (this.flag>1)this.flag=0;
        }
        if(this.flag==0)this.movie=0;
        
        if (okBtn.click(x, y).equalsIgnoreCase("true")){this.enable=0;outp='c';}
        
        //outp='t';
        }
            return outp;}
     
    public void setX(int X) { this.x=X;clsWindw.setX(this.x+this.width-clsWindw.getWidth()-2);}
    public void setY(int Y) { this.y=Y; clsWindw.setY(this.y+2);}
    public void setWidth(int W) {this.width=W; }
    public void setHeight(int H) {this.height=H; }
    public void setEnable(int H) {this.enable=H; }
    public int getEnable() { return this.enable; }
    public int getX() { return this.x; }
    public int getY() { return this.y; }
    public int getWidth(){return this.width; }
    public int getHeight(){return this.height;}

    public void draw(Graphics g) {
        if(this.enable==1){
g.clearRect(this.x, this.y, this.width, this.height);//очистка
g.setColor(Color.white);//установка белого
g.fillRect(this.x,this.y, this.width, this.height); //рисуем фон
g.setColor(Color.DARK_GRAY); //установка серого
g.drawRect(this.x,this.y, this.width, this.height);// рисуем окантовку}

g.setColor(Color.CYAN);
g.fillRect(this.x,this.y, this.width, 4+clsWindw.getHeight()); //рисуем фон
g.setColor(Color.DARK_GRAY);
g.drawString(title, x+10,this.y+clsWindw.getHeight()+2 );
//g.
g.setColor(Color.DARK_GRAY);
g.drawRect(this.x,this.y, this.width, 4+clsWindw.getHeight());// рисуем окантовку}

clsWindw.draw(g);
g.setColor(Color.black);
g.drawString("x",clsWindw.getX()+clsWindw.getWidth()/2 ,clsWindw.getY()+clsWindw.getHeight()-1 );

okBtn.draw(g);
g.setColor(Color.black);
g.drawString("OK",okBtn.getX()+okBtn.getWidth()/2-7 ,okBtn.getY()+okBtn.getHeight()-4 );
    }
    }

}
