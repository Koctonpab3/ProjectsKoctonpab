/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package visedit.windows;

import java.awt.Color;
import java.awt.Graphics;
import visedit.elements.ButtonImpl;

/**
 *
 * @author Uzver
 */
public class visWindow {
      int x,y,width,height,enable,movie,dx,dy,flag;
    String title="";
    public ButtonImpl clsWindw = new ButtonImpl(0,0,15,10,
            "resources\\bttn.jpg","resources\\bttn.jpg"); 
        public ButtonImpl crtPrj = new ButtonImpl(0,0,120,20,
            "resources\\bttn.jpg","resources\\bttn.jpg"); 
            public ButtonImpl opnPrj = new ButtonImpl(0,0,120,20,
            "resources\\bttn.jpg","resources\\bttn.jpg"); 
                public ButtonImpl clsPrg = new ButtonImpl(0,0,120,20,
            "resources\\bttn.jpg","resources\\bttn.jpg"); 
   
    public visWindow(int x1, int y1, int w, int h,int en){
   this.x=x1;
   this.y=y1;
   this.width=w;
   this.height=h;
   this.title="3D MIRROR";
   this.enable=en;
   this.movie=0;
   this.flag=0;
   clsWindw.setX(this.x+this.width-clsWindw.getWidth()-2);
   clsWindw.setY(this.y+2);
   crtPrj.setX(this.getX()+(this.getWidth()-crtPrj.getWidth())/2);
   crtPrj.setY(this.getY()+25);
   opnPrj.setX(this.getX()+(this.getWidth()-crtPrj.getWidth())/2);
   opnPrj.setY(this.getY()+20+((this.getHeight()-15)/3));
   clsPrg.setX(this.getX()+(this.getWidth()-crtPrj.getWidth())/2);
   clsPrg.setY(this.getY()+15+((this.getHeight()-15)/3)*2);
}
    public void movie(int x, int y){
        
if(this.movie==1){
    this.x=x-dx;//-(x-this.x);
    this.y=y-dy;//-(y-this.y);
    
   crtPrj.setX(this.getX()+(this.getWidth()-crtPrj.getWidth())/2);
   crtPrj.setY(this.getY()+15);
   opnPrj.setX(this.getX()+(this.getWidth()-crtPrj.getWidth())/2);
   opnPrj.setY(this.getY()+20+((this.getHeight()-15)/3));
   clsPrg.setX(this.getX()+(this.getWidth()-crtPrj.getWidth())/2);
   clsPrg.setY(this.getY()+25+((this.getHeight()-15)/3)*2);
   
    clsWindw.setX(this.x+this.width-clsWindw.getWidth()-2);
    clsWindw.setY(this.y+2);
        }
    }
    
     public char click(int x, int y) { 
         char outp='f';
        if((x>=this.x & x<=(this.x+this.width))&
                y>=this.y & y<=(this.y+this.height)& this.enable==1){
        if (clsWindw.click(x, y).equalsIgnoreCase("true")){outp='c';}
         
         if (crtPrj.click(x, y).equalsIgnoreCase("true")){outp='n';}
         if (opnPrj.click(x, y).equalsIgnoreCase("true")){outp='o';}
         if (clsPrg.click(x, y).equalsIgnoreCase("true")){outp='c';}
         
        this.movie=0;
        if((x>=this.x & x<=(this.x+this.width))&
                (y>=this.y & y<=(this.y+4+clsWindw.getHeight()))){this.movie=1;
    this.dx=(x-this.x);
    this.dy=(y-this.y);
    this.flag++;
    if (this.flag>1)this.flag=0;
        }
        if(this.flag==0)this.movie=0;
       
        //outp='t';
        }
        System.out.println(outp);
            return outp;}
     
    public void setX(int X) { this.x=X;clsWindw.setX(this.x+this.width-clsWindw.getWidth()-2);}
    public void setY(int Y) { this.y=Y; clsWindw.setY(this.y+2);}
    public void setWidth(int W) {this.width=W; }
    public void setHeight(int H) {this.height=H; }
    public void setEnable(int H) {this.enable=H; }
    public int getEnable() { return this.enable; }
    public int getX() { return this.x; }
    public int getY() { return this.y; }
    public int getWidth(){return this.width; }
    public int getHeight(){return this.height;}

    public void draw(Graphics g) {
        if(this.enable==1){
g.clearRect(this.x, this.y, this.width, this.height);//очистка
g.setColor(Color.white);//установка белого
g.fillRect(this.x,this.y, this.width, this.height); //рисуем фон
g.setColor(Color.DARK_GRAY); //установка серого
g.drawRect(this.x,this.y, this.width, this.height);// рисуем окантовку}

g.setColor(Color.CYAN);
g.fillRect(this.x,this.y, this.width, 4+clsWindw.getHeight()); //рисуем фон
g.setColor(Color.DARK_GRAY);
g.drawString(title, x+10,this.y+clsWindw.getHeight()+2 );
//g.
g.setColor(Color.DARK_GRAY);
g.drawRect(this.x,this.y, this.width, 4+clsWindw.getHeight());// рисуем окантовку}

clsWindw.draw(g);
g.setColor(Color.black);
g.drawString("x",clsWindw.getX()+6 ,clsWindw.getY()+clsWindw.getHeight()-1 );

crtPrj.draw(g);
g.setColor(Color.black);
g.drawString("Создать проект",crtPrj.getX()+7 ,crtPrj.getY()+crtPrj.getHeight()-4 );

opnPrj.draw(g);
g.setColor(Color.black);
g.drawString("Открыть проект",opnPrj.getX()+7 ,opnPrj.getY()+opnPrj.getHeight()-4 );

clsPrg.draw(g);
g.setColor(Color.black);
g.drawString("Выход",clsPrg.getX()+7 ,clsPrg.getY()+clsPrg.getHeight()-4 );

        
        }
    }

}
