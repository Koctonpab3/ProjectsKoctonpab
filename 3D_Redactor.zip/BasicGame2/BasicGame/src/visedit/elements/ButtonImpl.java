/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package visedit.elements;

import intrerfaces.visedit.Button;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.awt.image.ImageObserver;
import java.io.File;
import javax.imageio.ImageIO;

/**
 *
 * @author Admin
 */
public class ButtonImpl implements Button{
   int x,y,width,height,flag,Enable;
    String instr="pen";
       ImageObserver IobSer;
   BufferedImage img1 = null;
   BufferedImage img2 = null;
   BufferedImage imgDraw = null;
   
public ButtonImpl(int x, int y,int width,int height,String file,String file2){
this.x=x;
this.y=y;
this.width=width;
this.height=height;
this.flag=0;
if(img1==null) img1 =loadImage(file);
if(img2==null) img2 =loadImage(file2);
this.Enable=1;
} 

     public static BufferedImage loadImage(String ref) {
           BufferedImage bimg = null;
           try {

               bimg = ImageIO.read(new File(ref));
           } catch (Exception e) {
           }
           return bimg;
       }
   
   
    public String click(int x, int y) { 
        String outp="false";
        if((x>=this.x & x<=(this.x+this.width))&
                y>=this.y & y<=(this.y+this.height)& this.Enable==1){
        //    System.out.println("Xv"+this.x+" Yv"+this.y+" Wv"+this.width+" Hv"+this.height);
            outp="true";
        this.flag++;
        if (this.flag>1)this.flag=0;
        }
            return outp;}
    
    public void setX(int X) { this.x=X;}
    public void setY(int Y) { this.y=Y; }
    public void setWidth(int W) {this.width=W; }
    public void setHeight(int H) {this.height=H; }
    public void setEnable(int H) {this.Enable=H; }
    public void setFlag(int X) { this.flag=X;}
    public int getEnable() { return this.Enable; }
    public int getX() { return this.x; }
    public int getFlag() { return this.flag; }
    public int getY() { return this.y; }
    public int getWidth(){return this.width; }
    public int getHeight(){return this.height;}

    public void draw(Graphics g) {
        if(this.Enable==1){
        if(this.flag==0)this.imgDraw=this.img1;
        if(this.flag==1)this.imgDraw=this.img2;
g.clearRect(this.x, this.y, this.width, this.height);//очистка
g.drawImage(imgDraw, this.x, this.y,this.width,this.height, IobSer);
g.setColor(Color.DARK_GRAY); //установка серого
g.drawRect(this.x,this.y, this.width, this.height);// рисуем окантовку}
    }
    }
}
