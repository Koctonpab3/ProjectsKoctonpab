/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package visedit.elements;

import intrerfaces.visedit.Project;

/**
 *
 * @author Admin
 */
public class ProjectImpl implements Project {
  String type;
  String[][] MasSym = new String[10][20];
  String[][] MasCyl = new String[64][20];
  String[][][] MasAsm = new String[20][20][20];
  int width,height,depth,workLayer;
  
  public ProjectImpl(String type){
  this.type=type;
  
  if(this.type.equalsIgnoreCase("Sym")){
  this.width=10;
  this.height=20;
  this.depth=0;
  this.workLayer=0;
      for(int i=0;i<10;i++)
      for(int j=0;j<20;j++){
      this.MasSym[i][j]="000";
      }
  }
  if(this.type.equalsIgnoreCase("Cyl")){
  this.width=64;
  this.height=20;
  this.depth=0;
  this.workLayer=0;
      for(int i=0;i<64;i++)
      for(int j=0;j<20;j++){
      this.MasCyl[i][j]="000";
  }  
  }
  if(this.type.equalsIgnoreCase("Asm")){
    this.width=20;
  this.height=20;
  this.depth=20;
  this.workLayer=0;
      for(int i=0;i<20;i++)
      for(int j=0;j<20;j++)
      for(int z=0;z<20;z++){
      this.MasAsm[i][j][z]="000";
  }}}
public String getType(){return this.type;}
public int getWidth(){return this.width;}
public int getHeight(){return this.height;}
public int getDepth(){return this.depth;}
public void setType(String type){this.type=type;}
public void setWLayer(int type){this.workLayer=type;}
public int getWlayer(){return this.workLayer;}

public String[][][] getPrj(){
return this.MasAsm;
}
public void setPrj(String[][][]inMas){
    for(int z=0;z<20;z++)
    for(int y=0;y<20;y++)
    for(int x=0;x<20;x++){
    this.MasAsm[x][y][z]=inMas[x][y][z];
    }
    }
public void setPrjCh(char[][][]inMas){
    for(int z=0;z<20;z++)
    for(int y=0;y<20;y++)
    for(int x=0;x<20;x++){
    String out="";
     switch (inMas[x][y][z])
           {
               case 'R':
                   out="100";
               break;
               case 'G':
                   out="010";
               break;
               case 'B':
                   out="001";
               break;
               case 'Y':
                   out="110";
               break;
               case 'M':
                   out="101";
               break;
               case 'C':    
                   out="011";
               break;    
               case 'W':
                   out="111";
               break;    
               case '0':
                   out="000";
               break;    
               default:
                   out="000";
           }
     this.MasAsm[x][y][z]=out;
    }
}

public char[][][] getPrjCh(){
char[][][] masOut = new char[20][20][20];
if (this.getType().equalsIgnoreCase("Asm")){
    for(int z=0;z<20;z++)
    for(int y=0;y<20;y++)
    for(int x=0;x<20;x++){
    if(this.MasAsm[x][y][z].equalsIgnoreCase("000")){masOut[x][y][z]='0';}
    if(this.MasAsm[x][y][z].equalsIgnoreCase("001")){masOut[x][y][z]='B';}
    if(this.MasAsm[x][y][z].equalsIgnoreCase("010")){masOut[x][y][z]='G';}
    if(this.MasAsm[x][y][z].equalsIgnoreCase("100")){masOut[x][y][z]='R';}
    if(this.MasAsm[x][y][z].equalsIgnoreCase("011")){masOut[x][y][z]='C';}
    if(this.MasAsm[x][y][z].equalsIgnoreCase("101")){masOut[x][y][z]='M';}
    if(this.MasAsm[x][y][z].equalsIgnoreCase("110")){masOut[x][y][z]='Y';}
    if(this.MasAsm[x][y][z].equalsIgnoreCase("111")){masOut[x][y][z]='W';}
    }
}
return masOut;
}

public String[][] getLayer(int nl){
    String[][] out= new String[20][20];
    if (nl>-1 & nl<20){
    if (this.type=="Asm"){
    for(int i=0;i<20;i++)
    for(int j=0;j<20;j++){
    out[i][j]=this.MasAsm[i][j][nl];}
    }}
    return out;}
    
public void setLayer(String[][] Mas, int nl){
    if (nl>-1 & nl<20){
    if (this.type=="Asm"){
    for(int i=0;i<20;i++)
    for(int j=0;j<20;j++){
    this.MasAsm[i][j][nl]=Mas[i][j];}}}}

public String getVoxel(int x,int y,int z){
    String out="000";
    if (this.type=="Asm"){
    out=this.MasAsm[x][y][z];}
    if (this.type=="Cyl"){
    out=this.MasCyl[x][y];}
    if (this.type=="Sym"){
    out=this.MasSym[x][y];}
    
    return out;}
    

public void setVoxel(int x,int y,int z, String color){
      if (this.type=="Asm"){this.MasAsm[x][y][z]=color;}
    if (this.type=="Cyl"){this.MasCyl[x][y]=color;}
    if (this.type=="Sym"){this.MasSym[x][y]=color;}
}


}
