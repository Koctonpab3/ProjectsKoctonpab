/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package visedit.palitra;

import intrerfaces.visedit.EdPalitra;
import java.awt.Color;
import java.awt.Graphics;

/**
 *
 * @author Uzver
 */
public class EdPalitraImpl implements EdPalitra{
    int x,y,width=26,height=26;
    String color="000";
    
    public EdPalitraImpl(int x,int y,String color){
   this.x=x;
   this.y=y;
   this.color=color;
   } 
    
    public String click(int x, int y) { 
        String outp="";
        if (x>this.x & x<this.width+this.x & y>this.y & y<this.height+this.y )
        outp=this.color;
            return outp;}
    
    public void setX(int X) { this.x=X;}
    public void setY(int Y) { this.y=Y; }
    public void setWidth(int W) {this.width=W; }
    public void setHeight(int H) {this.height=H; }
    public int getX() { return this.x; }
    public int getY() { return this.y; }
    public int getWidth(){return this.width; }
    public int getHeight(){return this.height;}

    public void draw(Graphics g) {
g.clearRect(this.x, this.y, this.width, this.height);//очистка
g.setColor(Color.white);//установка белого
g.fillRect(this.x,this.y, this.width, this.height); //рисуем фон
if (this.color.equalsIgnoreCase("000")) g.setColor(Color.black);//установка белого
if (this.color.equalsIgnoreCase("001")) g.setColor(Color.BLUE);
if (this.color.equalsIgnoreCase("010")) g.setColor(Color.GREEN);
if (this.color.equalsIgnoreCase("100")) g.setColor(Color.red);
if (this.color.equalsIgnoreCase("011")) g.setColor(Color.cyan);
if (this.color.equalsIgnoreCase("110")) g.setColor(Color.yellow);
if (this.color.equalsIgnoreCase("101")) g.setColor(Color.magenta);
if (this.color.equalsIgnoreCase("111")) g.setColor(Color.white);
g.fillRect(this.x+3,this.y+3, this.width-5, this.height-5); //рисуем фон
g.setColor(Color.DARK_GRAY); //установка серого
g.drawRect(this.x,this.y, this.width, this.height);// рисуем окантовку}
    }
    public void setColor(String color) {this.color=color; }
    public String getColor() {return this.color;}
}
