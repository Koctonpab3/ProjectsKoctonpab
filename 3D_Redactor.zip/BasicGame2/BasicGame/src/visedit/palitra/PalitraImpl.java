/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package visedit.palitra;

import intrerfaces.visedit.Palitra;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.awt.image.ImageObserver;
import java.io.File;
import javax.imageio.ImageIO;
import static visedit.elements.ButtonImpl.loadImage;
/**
 *
 * @author Uzver
 */
public class PalitraImpl implements Palitra{
   int x,y,width=100,height=400,yp=100;
   String cur1="111",cur2="000";
    ImageObserver IobSer;
   BufferedImage img1 = null;
   
 EdPalitraImpl Pal1= new EdPalitraImpl(814,yp,"001");
 EdPalitraImpl Pal2= new EdPalitraImpl(844,yp,"010");
 EdPalitraImpl Pal3= new EdPalitraImpl(814,yp+30,"100");
 EdPalitraImpl Pal4= new EdPalitraImpl(844,yp+30,"110");
 EdPalitraImpl Pal5= new EdPalitraImpl(814,yp+60,"101");
 EdPalitraImpl Pal6= new EdPalitraImpl(844,yp+60,"011");
 EdPalitraImpl Pal7= new EdPalitraImpl(814,yp+90,"111");
 EdPalitraImpl Pal8= new EdPalitraImpl(844,yp+90,"000");
  
    
    
    public PalitraImpl(int x,int y){
   this.x=x;
   this.y=y;
   if(img1==null) img1 =loadImage("resources\\palit.jpg");
   } 
    
     public static BufferedImage loadImage(String ref) {
           BufferedImage bimg = null;
           try {

               bimg = ImageIO.read(new File(ref));
           } catch (Exception e) {
           }
           return bimg;
       }
    
    public String click(int x, int y,int Mbutton) { 
        String colPress="";
        
      if ((x>this.getX() & x<(this.getX()+this.getWidth())) & 
              (y>this.getY() & y<(this.getY()+this.getHeight()))){
        if(!"".equals(Pal1.click(x, y)))colPress=Pal1.click(x, y);
        if(!"".equals(Pal2.click(x, y)))colPress=Pal2.click(x, y);
        if(!"".equals(Pal3.click(x, y)))colPress=Pal3.click(x, y);
        if(!"".equals(Pal4.click(x, y)))colPress=Pal4.click(x, y);
        if(!"".equals(Pal5.click(x, y)))colPress=Pal5.click(x, y);
        if(!"".equals(Pal6.click(x, y)))colPress=Pal6.click(x, y);
        if(!"".equals(Pal7.click(x, y)))colPress=Pal7.click(x, y);
        if(!"".equals(Pal8.click(x, y)))colPress=Pal8.click(x, y);
        
        if (Mbutton==1)cur1=colPress;
        if (Mbutton==3)cur2=colPress;
      };
            return colPress;}
    
    public void setX(int X) { this.x=X;
    Pal1.setX(X);
    Pal2.setX(X+30);
    Pal3.setX(X);
    Pal4.setX(X+30);
    Pal5.setX(X);
    Pal6.setX(X+30);
    Pal7.setX(X);
    Pal8.setX(X+30);
    }
    public void setY(int Y) { this.y=Y; }
    public void setWidth(int W) {this.width=W; }
    public void setHeight(int H) {this.height=H; }
    public int getX() { return this.x; }
    public int getY() { return this.y; }
    public int getWidth(){return this.width; }
    public int getHeight(){return this.height;}
    public String getCur1() { return this.cur1; }
    public String getCur2() { return this.cur2; }

    public void draw(Graphics g) {
g.clearRect(this.x,yp+125,50,26);//очистка
g.setColor(Color.white);//установка белого
g.fillRect(this.x,yp+125,50,26); //рисуем фон
if (cur1.equalsIgnoreCase("000")) g.setColor(Color.black);//установка белого
if (cur1.equalsIgnoreCase("001")) g.setColor(Color.BLUE);
if (cur1.equalsIgnoreCase("010")) g.setColor(Color.GREEN);
if (cur1.equalsIgnoreCase("100")) g.setColor(Color.red);
if (cur1.equalsIgnoreCase("011")) g.setColor(Color.cyan);
if (cur1.equalsIgnoreCase("110")) g.setColor(Color.yellow);
if (cur1.equalsIgnoreCase("101")) g.setColor(Color.magenta);
if (cur1.equalsIgnoreCase("111")) g.setColor(Color.white);
g.fillRect(this.x,yp+135,26,26); //рисуем фон
g.setColor(Color.DARK_GRAY); //установка серого
g.drawRect(this.x,yp+135,26,26);// рисуем окантовку}

g.setColor(Color.white);//установка белого
g.fillRect(this.x+30,yp+135,26,26); //рисуем фон
if (cur2.equalsIgnoreCase("000")) g.setColor(Color.black);//установка белого
if (cur2.equalsIgnoreCase("001")) g.setColor(Color.BLUE);
if (cur2.equalsIgnoreCase("010")) g.setColor(Color.GREEN);
if (cur2.equalsIgnoreCase("100")) g.setColor(Color.red);
if (cur2.equalsIgnoreCase("011")) g.setColor(Color.cyan);
if (cur2.equalsIgnoreCase("110")) g.setColor(Color.yellow);
if (cur2.equalsIgnoreCase("101")) g.setColor(Color.magenta);
if (cur2.equalsIgnoreCase("111")) g.setColor(Color.white);

g.drawImage(img1, this.x+15, this.y-35,30,30, IobSer);
//g.fillRect(this.widthF-57,200,50,26); //рисуем фон
g.fillRect(this.x+30,yp+135,26,26); //рисуем фон
g.setColor(Color.DARK_GRAY); //установка серого
g.drawRect(this.x+30,yp+135,26,26);// рисуем окантовку}

    Pal1.draw(g);
    Pal2.draw(g);
    Pal3.draw(g);
    Pal4.draw(g);
    Pal5.draw(g);
    Pal6.draw(g);
    Pal7.draw(g);
    Pal8.draw(g);
    
    }   
}
