/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package visedit.pole;

import intrerfaces.visedit.voxel;

/**
 *
 * @author Uzver
 */
 class voxelFactory extends voxelGener {// Сама фабрика которая создает кнопки

    public voxelFactory() {
    }

    public voxel createObject(int Xpos, int Ypos, int x, int y,int width,int height, String color) {
        return new voxelImpl(Xpos,Ypos,x,y,width,height,color);
    }
    
}
