/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package visedit.pole;

import intrerfaces.visedit.voxel;
import java.awt.Color;
import java.awt.Graphics;

/**
 *
 * @author Uzver
 */
public class voxelImpl implements voxel {
int x,y,width,height,Xpos,Ypos;
String color="";

public voxelImpl(int Xpos, int Ypos, int x, int y,int width,int height, String color){
this.x=x;
this.y=y;
this.width=width;
this.height=height;
this.Xpos=Xpos;
this.Ypos=Ypos;
this.color=color;
}

public voxelImpl(int Xpos, int Ypos, String color){
this.x=x;
this.y=y;
this.Xpos=Xpos;
this.Ypos=Ypos;
this.color=color;
}

     public String click(int x, int y, String color) { 
        String outp="false";
        if((x>=this.x & x<=(this.x+this.width))&
                y>=this.y & y<=(this.y+this.height)){
           // System.out.println("Xv"+this.x+" Yv"+this.y+" Wv"+this.width+" Hv"+this.height);
        if( !"".equals(color)) this.color=color;
            outp="true";
        }
            return outp;}
    
    public void setX(int X) { this.x=X;}
    public void setY(int Y) { this.y=Y; }
    public void setXpos(int X) { this.Xpos=X;}
    public void setYpos(int Y) { this.Ypos=Y; }
    public void setWidth(int W) {this.width=W; }
    public void setHeight(int H) {this.height=H; }
    public int getX() { return this.x; }
    public int getY() { return this.y; }
    public int getXpos() { return this.Xpos; }
    public int getYpos() { return this.Ypos; }
    public int getWidth(){return this.width; }
    public int getHeight(){return this.height;}

    public void draw(Graphics g) {
g.clearRect(this.x, this.y, this.width, this.height);//очистка
g.setColor(Color.white);//установка белого
g.fillRect(this.x,this.y, this.width, this.height); //рисуем фон
//System.out.println("x"+this.getXpos()+" y"+this.getYpos()+" c:"+this.getColor());
if (this.color.equalsIgnoreCase("000")) g.setColor(Color.black);//установка белого
if (this.color.equalsIgnoreCase("001")) g.setColor(Color.BLUE);
if (this.color.equalsIgnoreCase("010")) g.setColor(Color.GREEN);
if (this.color.equalsIgnoreCase("100")) g.setColor(Color.red);
if (this.color.equalsIgnoreCase("011")) g.setColor(Color.cyan);
if (this.color.equalsIgnoreCase("110")) g.setColor(Color.yellow);
if (this.color.equalsIgnoreCase("101")) g.setColor(Color.magenta);
if (this.color.equalsIgnoreCase("111")) g.setColor(Color.white);
g.fillRect(this.x,this.y, this.width, this.height); //рисуем фон
g.setColor(Color.DARK_GRAY); //установка серого
g.drawRect(this.x,this.y, this.width, this.height);// рисуем окантовку}
    }
    public void setColor(String color) {this.color=color; }
    public String getColor() {return this.color;}

  
}
