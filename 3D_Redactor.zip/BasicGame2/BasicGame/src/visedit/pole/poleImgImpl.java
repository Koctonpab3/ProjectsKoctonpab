/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package visedit.pole;

import intrerfaces.visedit.poleImg;
import intrerfaces.visedit.voxel;
import java.awt.Color;
import java.awt.Graphics;
import static java.lang.Math.abs;
import java.util.Iterator;
import java.util.LinkedList;

/**
 *
 * @author Uzver
 */
public class poleImgImpl implements poleImg {
int x,y,width,height,Xvox,Yvox,flagBrush,modeBrush,flagUndo;
int x1=99,y1=99,x2=99,y2=99,maxX,maxY,minX,minY;
String Undo[][][]= new String [99][99][40];

public voxelGener ObjFact= voxelGener.getFactory();//фабрика кнопок
public LinkedList vxls = new LinkedList();//коллекция кнопок
String mode="",color2="";

public poleImgImpl(int x,int y,int width,int height,int Xvox,int Yvox){
    this.x=x;
    this.y=y;
    this.Xvox=Xvox;
    this.Yvox=Yvox;
    this.width=width;
    this.height=height;
    this.flagBrush=1;
    this.modeBrush=0;
    this.flagUndo=0;
    
    for(int x1=0;x1<99;x1++){
       for(int y1=0;y1<99;y1++){
           for(int z=0;z<40;z++){this.Undo[x1][y1][z]="000";}}}
               
    for(int i=0;i<this.Xvox;i++){
            for(int j=0;j<this.Yvox;j++){
                
                vxls.add(ObjFact.createObject(i,j,this.x+i*this.width/(this.Xvox+1)
                        ,this.y+j*this.height/(this.Yvox+1),(this.width/(this.Xvox+1))
                        ,(this.height/(this.Yvox+1)),"000")); 
             //   System.out.println("x"+(this.x+i*this.width/(this.Xvox))+" y"+(this.y+j*this.height/(this.Yvox))+" W"
             //           +this.width/(this.Xvox)+" H"+this.height/(this.Yvox));
            }
        }
}
    public void draw(Graphics g) {
        g.clearRect(this.x, this.y, this.width, this.height);//очистка
        g.setColor(Color.white);//установка белого
        g.fillRect(this.x,this.y, this.width, this.height); //рисуем фон
        g.setColor(Color.DARK_GRAY); //установка серого
        g.drawRect(this.x,this.y, this.width, this.height);// рисуем окантовку}
        
         if (!vxls.isEmpty()){
          Iterator itr = vxls.iterator();
         while(itr.hasNext()){
             Object element=itr.next();
             voxel Obj = (voxel) element;
          Obj.draw(g);
          }}
        
  }

    public void click(int x, int y, String color,String mode,String color2) {
        if((x>this.x & x<this.x+this.width)&
                (y>this.y & y<this.y+this.height)) {
        this.mode=mode;
       // System.out.println("Xm"+x+" Ym"+y);
        
            if(this.mode.equalsIgnoreCase("pen")){
                pen(x,y,color);
             }
        
            if(this.mode.equalsIgnoreCase("brush")){
                brush(x,y,color);        
             }
        
            if(this.mode.equalsIgnoreCase("line")){
             line(x,y,color);
            }
             
            if(this.mode.equalsIgnoreCase("rect")){
             rect(x,y,color,color2);
            }
            if(this.mode.equalsIgnoreCase("circle")){
             circle(x,y,color,color2);
            }
            if(this.mode.equalsIgnoreCase("copy")){
             copy(x,y);
            }
  }}

    
   
    
    public void setX(int X) {
        this.x=X;
         if (!vxls.isEmpty()){
          Iterator itr = vxls.iterator();
         while(itr.hasNext()){
             Object element=itr.next();
             voxel Obj = (voxel) element;
          Obj.setX(this.x+Obj.getXpos()*this.width/(this.Xvox));
          }}
    }

    public void setY(int Y) {
        this.y=Y;
         if (!vxls.isEmpty()){
          Iterator itr = vxls.iterator();
        while(itr.hasNext()){
             Object element=itr.next();
             voxel Obj = (voxel) element;
          Obj.setY(this.y+Obj.getYpos()*this.height/(this.Yvox));
          }}
    }

    public void setXvox(int Xvox) {this.Xvox=Xvox;}
    public void setYvox(int Yvox) {this.Yvox=Yvox;}

    public void setWidth(int W) {
        this.width=W;
        
        if (!vxls.isEmpty()){
          Iterator itr = vxls.iterator();
        while(itr.hasNext()){
             Object element=itr.next();
             voxel Obj = (voxel) element;
          Obj.setWidth(this.width/this.Xvox);
          }}
  }

    public void setHeight(int H) {
        this.height=H;
        
        if (!vxls.isEmpty()){
          Iterator itr = vxls.iterator();
        while(itr.hasNext()){
             Object element=itr.next();
             voxel Obj = (voxel) element;
          Obj.setHeight(this.height/this.Yvox);
          }}   
    }

    public void setPole(String[][] Mas) {
        for(int i=0;i<this.Xvox;i++){
            for(int j=0;j<this.Yvox;j++){
               
        if (!vxls.isEmpty()){
          Iterator itr = vxls.iterator();
        while(itr.hasNext()){
             Object element=itr.next();
             voxel Obj = (voxel) element;
             if (Obj.getXpos()==i & Obj.getYpos()==j)Obj.setColor(Mas[i][j]);
        }}   
            }
        }
  }
  
    public void setVoxel(int x, int y, String color) { 
        if (!vxls.isEmpty()){
          Iterator itr = vxls.iterator();
        while(itr.hasNext()){
             Object element=itr.next();
             voxel Obj = (voxel) element;
             if (Obj.getXpos()==x & Obj.getYpos()==y)Obj.setColor(color);
        }}}
    
    public int getX() { return this.x;}
    public int getY() { return this.y;}
    public int getXvox() {return this.Xvox;}
    public int getYvox() { return this.Yvox; }
    public int getWidth() { return this.width;}
    public int getHeight() { return this.height;}
    public String getVoxel(int x, int y) {
        String OutP="";
         if (!vxls.isEmpty()){
          Iterator itr = vxls.iterator();
        while(itr.hasNext()){
             Object element=itr.next();
             voxel Obj = (voxel) element;
             if (Obj.getXpos()==x & Obj.getYpos()==y)OutP=Obj.getColor();
        }}
        return OutP; }

    public String[][] getPole() {
      String Mas[][] = new String[this.Xvox][this.Yvox];
       for(int i=0;i<this.Xvox;i++)
           for(int j=0;j<this.Yvox;j++){
      if (!vxls.isEmpty()){
          Iterator itr = vxls.iterator();
        while(itr.hasNext()){
             Object element=itr.next();
             voxel Obj = (voxel) element;
             if (Obj.getXpos()==i & Obj.getYpos()==j)Mas[i][j]=Obj.getColor();
        }}}
            
        
    return Mas;
    }

         void save() {
       this.flagUndo++;
       if (this.flagUndo>39)this.flagUndo=0;
       
       for (int x1=0;x1<=this.Xvox;x1++)
           for (int y1=0;y1<=this.Yvox;y1++){
        if (!vxls.isEmpty()){
             Iterator itr = vxls.iterator();
                 while(itr.hasNext()){
                     Object element=itr.next();
                   voxel Obj = (voxel) element;
                if(Obj.getXpos()==x1 & Obj.getYpos()==y1){
                       this.Undo[x1][y1][this.flagUndo]=Obj.getColor();
                }
                
                 }}
        }
    }
    
    public void undo() {
       this.flagUndo--;
       
       if (this.flagUndo<0)this.flagUndo=39;
       
       for (int x1=0;x1<this.Xvox;x1++)
           for (int y1=0;y1<this.Yvox;y1++){
             if (!vxls.isEmpty()){
             Iterator itr = vxls.iterator();
                 while(itr.hasNext()){
                     Object element=itr.next();
                   voxel Obj = (voxel) element;
                   String color = this.Undo[x1][y1][flagUndo];
                if(Obj.getXpos()==x1 & Obj.getYpos()==y1)Obj.setColor(color);
                }}
        }
    
    }

    public void redo() {
    this.flagUndo++;
       
       if (this.flagUndo>39)this.flagUndo=0;
       
       for (int x1=0;x1<this.Xvox;x1++)
           for (int y1=0;y1<this.Yvox;y1++){
        if (!vxls.isEmpty()){
             Iterator itr = vxls.iterator();
                 while(itr.hasNext()){
                     Object element=itr.next();
                   voxel Obj = (voxel) element;
                   String color = this.Undo[x1][y1][flagUndo];
                if(Obj.getXpos()==x1 & Obj.getYpos()==y1)Obj.setColor(color);
                }}
        }
    }
    void pen(int x, int y, String color){
                 if (!vxls.isEmpty()){
             Iterator itr = vxls.iterator();
                 while(itr.hasNext()){
                     Object element=itr.next();
                   voxel Obj = (voxel) element;
                Obj.click(x, y, color);
                }}
                 
        save();
    }
    void brush(int x, int y, String color){
     int x1=99,y1=99;
             if (!vxls.isEmpty()){
             Iterator itr = vxls.iterator();
                 while(itr.hasNext()){
                     Object element=itr.next();
                   voxel Obj = (voxel) element;
                if(Obj.click(x, y, color).equalsIgnoreCase("true")){
                x1=Obj.getXpos();
                y1=Obj.getYpos();
                };
                }}
             
             if (!vxls.isEmpty()){
             Iterator itr = vxls.iterator();
                 while(itr.hasNext()){
                     Object element=itr.next();
                   voxel Obj = (voxel) element;
                if (Obj.getXpos()==(x1-1)& Obj.getYpos()==(y1)&(x1-1)>=0){Obj.setColor(color);}
                if (Obj.getXpos()==(x1+1)& Obj.getYpos()==(y1)&(x1+1)<=this.Xvox){Obj.setColor(color);}
                if (Obj.getXpos()==(x1)& Obj.getYpos()==(y1+1)&(y1+1)<=this.Yvox){Obj.setColor(color);}
                if (Obj.getXpos()==(x1)& Obj.getYpos()==(y1-1)&(y1-1)>=0){Obj.setColor(color);}
                 }}
    save();
    }
    
    void lineParam(int xa1, int ya1,int xa2,int ya2,String color){
    
     int beg=0,fin=0,by1=0,by2=0;
        if((abs(xa1-xa2)-abs(ya1-ya2))>=0){
          if (xa1<xa2){beg=xa1;fin=xa2;by1=ya1;by2=ya2;}
          if (xa1>xa2){beg=xa2;fin=xa1;by1=ya2;by2=ya1;}
            int A=by1-by2,B=fin-beg,C=-A*beg-B*by1;
            
            for(int i=beg;i<=fin;i++){
            if (!vxls.isEmpty()){
              int Yr=0;
               if(B!=0)Yr=(-A*i-C)/B;
             Iterator itr = vxls.iterator();
                 while(itr.hasNext()){
                     Object element=itr.next();
                   voxel Obj = (voxel) element;
                if(Obj.getXpos()==i & Obj.getYpos()==Yr){Obj.setColor(color);}
                }}}
            
        }
        
        if((abs(xa1-xa2)-abs(ya1-ya2))<0){
          if (ya1<ya2){beg=ya1;fin=ya2;by1=xa1;by2=xa2;}
          if (ya1>ya2){beg=ya2;fin=ya1;by1=xa2;by2=xa1;}  
            int A=by1-by2,B=fin-beg,C=-A*beg-B*by1;
            
            for(int i=beg;i<=fin;i++){
            if (!vxls.isEmpty()){
              int Yr=(-A*i-C)/B;
             Iterator itr = vxls.iterator();
                 while(itr.hasNext()){
                     Object element=itr.next();
                   voxel Obj = (voxel) element;
                if(Obj.getYpos()==i & Obj.getXpos()==Yr){Obj.setColor(color);}
                }}}
            
        }
        
        if(xa1==xa2){
          if (ya1<ya2){beg=ya1;fin=ya2;}
          if (ya1>ya2){beg=ya2;fin=ya1;}
        for(int i=beg;i<=fin;i++){
             if (!vxls.isEmpty()){
             Iterator itr = vxls.iterator();
                 while(itr.hasNext()){
                     Object element=itr.next();
                   voxel Obj = (voxel) element;
                if(Obj.getXpos()==xa1 & Obj.getYpos()==i){Obj.setColor(color);}
                }}
        }}
        
        if(ya1==ya2){
          if (xa1<xa2){beg=xa1;fin=xa2;}
          if (xa1>xa2){beg=xa2;fin=xa1;}
        for(int i=beg;i<=fin;i++){
             if (!vxls.isEmpty()){
             Iterator itr = vxls.iterator();
                 while(itr.hasNext()){
                     Object element=itr.next();
                   voxel Obj = (voxel) element;
                if(Obj.getYpos()==ya1 & Obj.getXpos()==i){Obj.setColor(color);}
                }}
        }}
        
    }
    
    void line(int x, int y, String color){
    if (flagBrush==2){
             if (!vxls.isEmpty()){
             Iterator itr = vxls.iterator();
                 while(itr.hasNext()){
                     Object element=itr.next();
                   voxel Obj = (voxel) element;
                if(Obj.click(x, y, color).equalsIgnoreCase("true")){
                x2=Obj.getXpos();
                y2=Obj.getYpos();
                lineParam(x1,y1,x2,y2,color);
                }}}
             this.flagBrush=3;
             }
             
              if (this.flagBrush==1){
             if (!vxls.isEmpty()){
             Iterator itr = vxls.iterator();
                 while(itr.hasNext()){
                     Object element=itr.next();
                   voxel Obj = (voxel) element;
                if(Obj.click(x, y, color).equalsIgnoreCase("true")){
                x1=Obj.getXpos();
                y1=Obj.getYpos();
                };
                }}
             this.flagBrush=2;
             }
             if(this.flagBrush==3){this.flagBrush=1;save();}
    }
    void rect(int x, int y, String color, String color2){
               if (flagBrush==2){
             if (!vxls.isEmpty()){
             Iterator itr = vxls.iterator();
                 while(itr.hasNext()){
                     Object element=itr.next();
                   voxel Obj = (voxel) element;
                if(Obj.click(x, y, color).equalsIgnoreCase("true")){
                x2=Obj.getXpos();
                y2=Obj.getYpos();
                
                minX=x1;maxX=x2;minY=y1;maxY=y2;
                if(x1<x2){minX=x1;maxX=x2;}
                if(x1>x2){minX=x2;maxX=x1;}
                if(y1<y2){minY=y1;maxY=y2;}
                if(y1>y2){minY=y2;maxY=y1;}
                
                for(int i=minX;i<=maxX;i++){
                for(int j=minY;j<=maxY;j++){
                
             if (!vxls.isEmpty()){
             Iterator itr2 = vxls.iterator();
                 while(itr2.hasNext()){
                     Object element2=itr2.next();
                   voxel Obj2 = (voxel) element2;
                if (this.modeBrush==1){
                   if (((Obj2.getXpos()==(i))&
                (Obj2.getYpos()<maxY)&(Obj2.getYpos()>minY))|(((Obj2.getYpos()==(j))&
                        Obj2.getXpos()<maxX)&(Obj2.getXpos()>minX))){
                Obj2.setColor(color2);
                }}
                 
                     if (((Obj2.getXpos()==(minX))|(Obj2.getXpos()==(maxX)))&
                        ((Obj2.getYpos()<=maxY)&(Obj2.getYpos()>=minY))){
                         Obj2.setColor(color);}
                     if (((Obj2.getYpos()==(minY))|(Obj2.getYpos()==(maxY)))&
                        ((Obj2.getXpos()<=maxX)&(Obj2.getXpos()>=minX))){
                         Obj2.setColor(color);}
                
                 }}}}}
                }}
             this.flagBrush=3;
             }
             
              if (this.flagBrush==1){
             if (!vxls.isEmpty()){
             Iterator itr = vxls.iterator();
                 while(itr.hasNext()){
                     Object element=itr.next();
                   voxel Obj = (voxel) element;
                if(Obj.click(x, y, color).equalsIgnoreCase("true")){
                x1=Obj.getXpos();
                y1=Obj.getYpos();
                };
                }}
             this.flagBrush=2;
             }
             if(this.flagBrush==3){this.flagBrush=1;save();}
            
    }
    
    
    
    void circle(int x, int y, String color,String color2){
            if (flagBrush==2){
             if (!vxls.isEmpty()){
             Iterator itr = vxls.iterator();
                 while(itr.hasNext()){
                   Object element=itr.next();
                   voxel Obj = (voxel) element;
                if(Obj.click(x, y,"").equalsIgnoreCase("true")){
                x2=Obj.getXpos();
                y2=Obj.getYpos();
                
                int Radius=(int)Math.sqrt((x1-x2)*(x1-x2)+(y1-y2)*(y1-y2));
                
                if (this.modeBrush!=1){
                circleParam(x1,y1,Radius,color);
                }
                
                if (this.modeBrush==1){
                for(int i=0;i<Radius;i++){
                    circleParam(x1,y1,i,color2);
                }
                 circleParam(x1,y1,Radius,color);
                }
                
                }
                }}
             this.flagBrush=3;
             }
             
              if (this.flagBrush==1){
             if (!vxls.isEmpty()){
             Iterator itr = vxls.iterator();
                 while(itr.hasNext()){
                   Object element=itr.next();
                   voxel Obj = (voxel) element;
                if(Obj.click(x, y, "").equalsIgnoreCase("true")){
                x1=Obj.getXpos();
                y1=Obj.getYpos();
                };
                }}
             this.flagBrush=2;
             }
             if(this.flagBrush==3){this.flagBrush=1;save();}
     
        
    }
    
    void circleParam(int x , int y,int R,String color){
    int mX,maX,mY,maY;
         mX=x-R;maX=x+R;
         
         for(int i=mX;i<=maX;i++){
               
                int Ycirc=y+(int)Math.sqrt(R*R-(i-x)*(i-x));
                int j=i-(x-y);
                int Xcirc=x+(int)Math.sqrt(R*R-(j-y)*(j-y));
                
             if (!vxls.isEmpty()){
             Iterator itr2 = vxls.iterator();
                 while(itr2.hasNext()){
                     Object element2=itr2.next();
                   voxel Obj2 = (voxel) element2;
                             if (((Obj2.getYpos()==Ycirc)|
                             (Obj2.getYpos()==(2*y-Ycirc)))&
                             (Obj2.getXpos()==i)){
                                                Obj2.setColor(color);}
                     if (((Obj2.getXpos()==Xcirc)|
                             (Obj2.getXpos()==(2*x-Xcirc)))&
                             (Obj2.getYpos()==j)){
                                                Obj2.setColor(color);}
                
                 }}}
        
    }
    
    void copyParam(int x1,int y1,int x2,int y2,int x3,int y3){
    int begX=0,finX=0,begY=0,finY=0;
    String[][] buff=new String[99][99]; 
        if(x1!=x2 | y1!=y2){
            if (x1>x2){begX=x2;finX=x1;}
            if (x1<x2){begX=x1;finX=x2;}
            if (y1>y2){begY=y2;finY=y1;}
            if (y1<y2){begY=y1;finY=y2;}
            
            for (int x=begX;x<=finX;x++){
            for (int y=begY;y<=finY;y++){
           if (!vxls.isEmpty()){
             Iterator itr = vxls.iterator();
                 while(itr.hasNext()){
                     Object element=itr.next();
                   voxel Obj = (voxel) element;
                if(Obj.getXpos()==x & Obj.getYpos()==y){buff[x-begX][y-begY]=Obj.getColor();}
                }}    
            }}
            
            for (int x=x3;x<=(x3+finX-begX);x++){
            for (int y=y3;y<=(y3+finY-begY);y++){
           if (!vxls.isEmpty()){
             Iterator itr = vxls.iterator();
                 while(itr.hasNext()){
                     Object element=itr.next();
                   voxel Obj = (voxel) element;
                if(Obj.getXpos()==x & Obj.getYpos()==y){Obj.setColor(buff[x-x3][y-y3]);}
                }}    
            }}
            
        }}
    
    void copy(int x, int y ){
       
        if (flagBrush==3){
             if (!vxls.isEmpty()){
             Iterator itr = vxls.iterator();
                 while(itr.hasNext()){
                     Object element=itr.next();
                   voxel Obj = (voxel) element;
                if(Obj.click(x, y, "").equalsIgnoreCase("true")){
                int x3=Obj.getXpos();
                int y3=Obj.getYpos();
               copyParam(x1,y1,x2,y2,x3,y3);
                }
                }}
             this.flagBrush=4;
             }
        
        if (flagBrush==2){
             if (!vxls.isEmpty()){
             Iterator itr = vxls.iterator();
                 while(itr.hasNext()){
                     Object element=itr.next();
                   voxel Obj = (voxel) element;
                if(Obj.click(x, y, "").equalsIgnoreCase("true")){
                x2=Obj.getXpos();
                y2=Obj.getYpos();
               }
                }}
             this.flagBrush=3;
             }
             
              if (this.flagBrush==1){
             if (!vxls.isEmpty()){
             Iterator itr = vxls.iterator();
                 while(itr.hasNext()){
                     Object element=itr.next();
                   voxel Obj = (voxel) element;
                if(Obj.click(x, y, "").equalsIgnoreCase("true")){
                x1=Obj.getXpos();
                y1=Obj.getYpos();
                };
                }}
             this.flagBrush=2;
             }
             if(this.flagBrush==4){this.flagBrush=1;save();}
            
    }

    public void setMode(int mode){
    this.modeBrush=mode;
    }  
    
    public int getMode(){return this.modeBrush;}

}
