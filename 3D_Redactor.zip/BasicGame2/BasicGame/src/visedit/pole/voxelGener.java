/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package visedit.pole;

import intrerfaces.visedit.voxel;

/**
 *
 * @author Uzver
 */
public abstract class voxelGener {
   //это Абстрактная фабрика создания Кнопок

                 static voxelGener getFactory() {// Создание обьекта фабрики
    return new voxelFactory();
}
 
 public abstract voxel createObject(int Xpos, int Ypos, int x, int y,int width,int height, String color);


}
    
