/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package visedit.menu;

import java.awt.Color;
import java.awt.Graphics;

/**
 *
 * @author Uzver
 */
public class menuImpl {
     int x,y,width,height,enable;
   
   public menuImpl(int x,int y,int en){
   this.x=x;
   this.y=y;
   this.width=150;
   this.height=140;
   this.enable=en;
   } 
    
    public char click(int x, int y) { 
        char outp=' ';
        if (x>this.x & x<(this.width+this.x) & y>this.y & y<(this.height+this.y)
                & this.enable==1){
        //System.out.println("x:"+x+" y:"+y);
        if(y<(20+this.y))outp='1';
        if(y>(this.y+20) & y<(this.y+40))outp='2';
        if(y>(this.y+40) & y<(this.y+60))outp='3';
        if(y>(this.y+60) & y<(this.y+80))outp='4';
        if(y>(this.y+80) & y<(this.y+100))outp='5';
        if(y>(this.y+100) & y<(this.y+120))outp='6';
        if(y>(this.y+120) & y<(this.y+140))outp='7';
        System.out.println(outp);
        }
            return outp;}
     public void draw(Graphics g){
         if(this.enable==1){
g.clearRect(this.x, this.y, this.width, this.height);//очистка
g.setColor(Color.white);//установка белого
g.fillRect(this.x,this.y, this.width, this.height); //рисуем фон
g.setColor(Color.DARK_GRAY); //установка серого
g.drawRect(this.x,this.y, this.width, this.height);// рисуем окантовку
g.setColor(Color.BLACK);//установка черного
g.drawString("Новый проект", this.x+5, this.y+17); //прорисовка заголовка
g.drawLine(this.x, this.y+20, this.x+this.width, this.y+20);
g.drawString("Открыть проект", this.x+5, this.y+37); //прорисовка заголовка
g.drawLine(this.x, this.y+40, this.x+this.width, this.y+40);
g.drawString("Сохранить проект", this.x+5, this.y+57); //прорисовка заголовка
g.drawLine(this.x, this.y+60, this.x+this.width,this.y+ 60);
g.drawString("Открыть кадр(слой)", this.x+5, this.y+77); //прорисовка заголовка
g.drawLine(this.x, this.y+80, this.x+this.width, this.y+80);
g.drawString("Сохранить кадр(слой)", this.x+5, this.y+97); //прорисовка заголовка
g.drawLine(this.x, this.y+100, this.x+this.width, this.y+100);
g.drawString("Настройки", this.x+5, this.y+117); //прорисовка заголовка
g.drawLine(this.x,this.y+120, this.x+this.width, this.y+120);
g.drawString("Выход", this.x+5, this.y+137); //прорисовка заголовка
         }
   }
   
    public void setX(int X) { this.x=X;}
    public void setY(int Y) { this.y=Y; }
    public void setWidth(int W) {this.width=W; }
    public void setHeight(int H) {this.height=H; }
    public void setEnable(int H) {this.enable=H; }
    public int getEnable() { return this.enable; }
    public int getX() { return this.x; }
    public int getY() { return this.y; }
    public int getWidth(){return this.width; }
    public int getHeight(){return this.height;}
}
