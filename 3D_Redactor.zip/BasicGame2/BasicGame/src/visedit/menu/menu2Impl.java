/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package visedit.menu;

import java.awt.Color;
import java.awt.Graphics;

/**
 *
 * @author Uzver
 */
public class menu2Impl {
     int x,y,width,height,enable;
   
   public menu2Impl(int x,int y,int en){
   this.x=x;
   this.y=y;
   this.width=150;
   this.height=80;
   this.enable=en;
   } 
    
    public char click(int x, int y) { 
        char outp=' ';
        if (x>this.x & x<(this.width+this.x) & y>this.y & y<(this.height+this.y)
                & this.enable==1){
        //System.out.println("x:"+x+" y:"+y);
        if(y<(20+this.y))outp='1';
        if(y>(this.y+20) & y<(this.y+40))outp='2';
        if(y>(this.y+40) & y<(this.y+60))outp='3';
        if(y>(this.y+60) & y<(this.y+80))outp='4';
        System.out.println(outp);
        }
            return outp;}
     public void draw(Graphics g){
         if(this.enable==1){
g.clearRect(this.x, this.y, this.width, this.height);//очистка
g.setColor(Color.white);//установка белого
g.fillRect(this.x,this.y, this.width, this.height); //рисуем фон
g.setColor(Color.DARK_GRAY); //установка серого
g.drawRect(this.x,this.y, this.width, this.height);// рисуем окантовку
g.setColor(Color.BLACK);//установка черного
g.drawString("Отменить действие", this.x+5, this.y+17); //прорисовка заголовка
g.drawLine(this.x, this.y+20, this.x+this.width, this.y+20);
g.drawString("Повторить действие", this.x+5, this.y+37); //прорисовка заголовка
g.drawLine(this.x, this.y+40, this.x+this.width, this.y+40);
g.drawString("Преобраз img в слой", this.x+5, this.y+57); //прорисовка заголовка
g.drawLine(this.x, this.y+60, this.x+this.width,this.y+ 60);
g.drawString("Очистить слой", this.x+5, this.y+77); //прорисовка заголовка

         }
   }
   
    public void setX(int X) { this.x=X;}
    public void setY(int Y) { this.y=Y; }
    public void setWidth(int W) {this.width=W; }
    public void setHeight(int H) {this.height=H; }
    public void setEnable(int H) {this.enable=H; }
    public int getEnable() { return this.enable; }
    public int getX() { return this.x; }
    public int getY() { return this.y; }
    public int getWidth(){return this.width; }
    public int getHeight(){return this.height;}
}
