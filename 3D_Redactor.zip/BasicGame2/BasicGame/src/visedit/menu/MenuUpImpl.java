/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package visedit.menu;

import intrerfaces.visedit.MenuUp;
import java.awt.Color;
import java.awt.Graphics;

/**
 *
 * @author Uzver
 */
public class MenuUpImpl implements MenuUp{
    int x,y,width,height;
   
   public MenuUpImpl(int x,int y,int w,int h){
   this.x=x;
   this.y=y;
   this.width=w;
   this.height=h;
   } 
    
   public void draw(Graphics g){
g.clearRect(this.x, this.y, this.width, this.height);//очистка
g.setColor(Color.white);//установка белого
g.fillRect(this.x,this.y, this.width, this.height); //рисуем фон
g.setColor(Color.DARK_GRAY); //установка серого
g.drawRect(this.x,this.y, this.width, this.height);// рисуем окантовку
g.setColor(Color.BLACK);//установка черного
g.drawString("Файл", this.x+10, this.y+38); //прорисовка заголовка
//g.drawLine(45, 25, 45, 42);
g.drawString("Правка", this.x+75, this.y+38); //прорисовка заголовка
//g.drawLine(104, 25, 104, 42);
g.drawString("О программе", this.x+150, this.y+38); //прорисовка заголовка
//g.drawLine(190, 25, 190, 42);
   }
   
    public char click(int x, int y) { 
        char outp=' ';
        if (x>this.x & x<this.width+this.x & y>this.y & y<this.height+this.y ){
        System.out.println("x:"+x+" y:"+y);
        if(x>0 & x<55)outp='1';
        if(x>55 & x<135)outp='2';
        if(x>135 & x<240)outp='3';
        }
            return outp;}
    public void setX(int X) { this.x=X;}
    public void setY(int Y) { this.y=Y; }
    public void setWidth(int W) {this.width=W; }
    public void setHeight(int H) {this.height=H; }
    public int getX() { return this.x; }
    public int getY() { return this.y; }
    public int getWidth(){return this.width; }
    public int getHeight(){return this.height;}
}
