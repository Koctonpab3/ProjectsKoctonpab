/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package visedit.preview;

import com.jme3.asset.AssetManager;
import com.jme3.math.ColorRGBA;
import com.jme3.math.Vector3f;
import com.jme3.scene.Geometry;
import com.jme3.scene.shape.Box;

/**
 *
 * @author Admin
 */
public class factory extends gener {// Сама фабрика которая создает кнопки

    public factory() {
    }

    public myBox createObject(float x,float y,float z,float x1,
            float y1,float z1,AssetManager am,ColorRGBA col) {
        return new myBox(x,y,z,x1,y1,z1,am,col);
    }}
