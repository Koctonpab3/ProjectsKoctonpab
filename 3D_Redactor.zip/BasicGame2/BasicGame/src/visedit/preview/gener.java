/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package visedit.preview;

import com.jme3.asset.AssetManager;
import com.jme3.math.ColorRGBA;
import com.jme3.math.Vector3f;
import com.jme3.scene.shape.Box;

/**
 *
 * @author Admin
 */
public abstract class gener {
   //это Абстрактная фабрика создания Кнопок

                 static gener getFactory() {// Создание обьекта фабрики
    return new factory();
}
 
 public abstract myBox createObject(float x,float y,float z,float x1,
         float y1,float z1,AssetManager am,ColorRGBA col);


}