package visedit.preview;

import com.jme3.app.SimpleApplication;
import com.jme3.input.KeyInput;
import com.jme3.input.controls.ActionListener;
import com.jme3.material.Material;
import com.jme3.math.ColorRGBA;
import com.jme3.math.FastMath;
import com.jme3.math.Quaternion;
import com.jme3.math.Vector2f;
import com.jme3.renderer.RenderManager;
import com.jme3.scene.Geometry;
import com.jme3.scene.Node;
import com.jme3.system.AppSettings;
import com.jme3.input.controls.KeyTrigger;
import com.jme3.input.controls.MouseButtonTrigger;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Random;

/**
 * test
 * @author normenhansen
 */
public class Preview extends SimpleApplication {
 Node pivot = new Node("pivot");
  static int scrResX=800,scrResY=600;
 public LinkedList vxls = new LinkedList();
 public gener ObjFact= gener.getFactory();
 char [][][] mas=new char[20][20][20];
 boolean isDragging = false;
Vector2f mouseCoords = new Vector2f(0,0);
Vector2f targetRotation = new Vector2f(0,0);
boolean turnTable = true;


public void masMas(char[][][] inMas){
     for(int z=0;z<20;z++)
    for(int y=0;y<20;y++)
        for(int x=0;x<20;x++){
this.mas[x][y][z]=inMas[x][y][z];  
System.out.println("mas "+mas[x][y][z]+" a" );
        }
}
//public Preview(){}
    public void init(char[][][] inMas) {
//Preview app = new Preview();
AppSettings cfg = new AppSettings(true);
cfg.setFrameRate(60); // set to less than or equal screen refresh rate
cfg.setVSync(false);   // prevents page tearing
cfg.setFrequency(60); // set to screen refresh rate
cfg.setResolution(Preview.scrResX, Preview.scrResY);   
cfg.setFullscreen(false); 
cfg.setSamples(0);    // anti-aliasing
cfg.setTitle("3D MIRROR preview"); // branding: window name

this.setShowSettings(false); // or don't display splashscreen
this.setSettings(cfg);


 for(int z=0;z<20;z++)
    for(int y=0;y<20;y++)
        for(int x=0;x<20;x++){
this.mas[x][19-y][z]=inMas[x][y][z];  
System.out.println("mas "+this.mas[x][y][z]+" a" );
        }

this.start();
 

    }

  
    public void simpleInitApp() {
        
        flyCam.setRotationSpeed(10f);
        flyCam.setMoveSpeed(10f);
        flyCam.setZoomSpeed(100f);
        flyCam.setEnabled(paused);
         
       
        rootNode.attachChild(pivot);
        
     viewPort.setBackgroundColor(ColorRGBA.Black);

    for(int z=0;z<20;z++)
    for(int y=0;y<20;y++)
        for(int x=0;x<20;x++)
        {
         float xS,yS,zS,xS1,zS1,yS1,k=0.3f;
            xS=(float) ((x-10)*k);
            yS=(float)((y-10)*k);
            zS=(float)((z-10)*k);
            xS1=(float)((x-9)*k);
            yS1=(float)((y-9)*k);
            zS1=(float)((z-9)*k);
            if (this.mas[x][y][z]=='0'){
             //xS=0;yS=0; zS=0;
             xS1=xS;yS1=yS; zS1=zS;
            }
            vxls.add(ObjFact.createObject((xS),(yS),(zS),
                 (xS1),(yS1),(zS1),assetManager,ColorRGBA.Blue));
            System.out.println("mas1 "+this.mas[x][y][z]+" a" );
        }
    
       if (!vxls.isEmpty()){
          Iterator itr = vxls.iterator();
          int x=0,y=0,z=0;
         while(itr.hasNext()){
             Object element=itr.next();
             myBox Obj = (myBox) element;
             if (this.mas[x][y][z]=='B'){
             initBox(Obj,ColorRGBA.Blue);
             }
             if (this.mas[x][y][z]=='G'){
             initBox(Obj,ColorRGBA.Green);
             }
             if (this.mas[x][y][z]=='R'){
             initBox(Obj,ColorRGBA.Red);
             }
             if (this.mas[x][y][z]=='C'){
             initBox(Obj,ColorRGBA.Cyan);
             }
             if (this.mas[x][y][z]=='M'){
             initBox(Obj,ColorRGBA.Magenta);
             }
             if (this.mas[x][y][z]=='Y'){
             initBox(Obj,ColorRGBA.Yellow);
             }
             if (this.mas[x][y][z]=='W'){
             initBox(Obj,ColorRGBA.White);
             }
             if (this.mas[x][y][z]=='0'){
             initBox(Obj,ColorRGBA.Black);
             }
             
            x++;
            if (x>19){x=0;y++;}
            if(y>19){y=0;z++;}
          }}
       
  
      rootNode.attachChild(pivot);
      
      // Add left mouse button for dragging
inputManager.addMapping("Drag", new MouseButtonTrigger(0));
inputManager.addListener(actionListener, "Drag");
 
// Add mode toggle button for explanation of rotation
inputManager.addMapping("ModeToggle", new KeyTrigger(KeyInput.KEY_T));
inputManager.addListener(actionListener, "ModeToggle");
    }
    
    public void initBox(myBox box,ColorRGBA col){
         Geometry geom = new Geometry("Box", box.b);
      Material mat = new Material(assetManager, "Common/MatDefs/Misc/Unshaded.j3md");
     mat.setColor("Color", col);
     geom.setMaterial(mat);
     rootNode.attachChild(geom);
     pivot.attachChild(geom);
    }
    

    @Override
    public void simpleUpdate(float tpf) {
        //TODO: add update code/* A colored lit cube. Needs light source! */ 
if (isDragging){
 
// Find change of mouse position for dragging direction and distance
Vector2f movement = inputManager.getCursorPosition().subtract(mouseCoords).mult(0.01f);
 
if (turnTable){ // Up stays up for visual feel, "Turntable"
// Note: Improvements can be made here using quaternions in a better way, this is just as an example
targetRotation.addLocal(movement);
float z;
z=FastMath.PI/2;
targetRotation.y = Math.min(Math.max(targetRotation.y, (z*(-1))), z);
pivot.setLocalRotation(Quaternion.IDENTITY);        // Go back to starting UP
pivot.rotate(-targetRotation.y, 0, 0);            // Rotation about the X-Axis
pivot.rotate(0, targetRotation.x, 0);            // Rotation about the Y-Axis
}
else // True up as system considers it, "Trackball"
pivot.rotate(-movement.y, movement.x, 0);
 
// Store input data for later use
mouseCoords = inputManager.getCursorPosition().clone();
}

    }

    @Override
    public void simpleRender(RenderManager rm) {
        //TODO: add render code
    }
    
     /** Pick a Target Using the Mouse Pointer. <ol><li>Map "pick target" action to a MouseButtonTrigger. <li>flyCam.setEnabled(false); <li>inputManager.setCursorVisible(true); <li>Implement action in AnalogListener (TODO).</ol>
 */


private ActionListener actionListener = new ActionListener() {
public void onAction(String binding, boolean value, float tpf) {
if (binding.equals("Drag")){
isDragging = value;
// Forget about previous dragging position when initiating drag
mouseCoords = new Vector2f(inputManager.getCursorPosition());
}
else if (binding.equals("ModeToggle") && value){
//turnTable = !turnTable;
// Reset rotation of the object
pivot.setLocalRotation(Quaternion.IDENTITY);

// Reset target rotation for Turntable mode
targetRotation = new Vector2f(0,0);
System.out.println("Turntable mode is: " + turnTable);
}
}
};
      
}

