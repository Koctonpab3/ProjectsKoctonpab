/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package visedit.preview;

import com.jme3.asset.AssetManager;
import com.jme3.material.Material;
import com.jme3.math.ColorRGBA;
import com.jme3.math.Vector3f;
import com.jme3.scene.Geometry;
import com.jme3.scene.shape.Box;

/**
 *
 * @author Admin
 */
public class myBox {
    private final AssetManager am1;
   Geometry geom;
   Box b;
    public myBox(float x,float y,float z,float x1,float y1,float z1,AssetManager am,ColorRGBA col){
        b= new Box( new Vector3f(x, y, z), new Vector3f(x1, y1, z1));
        geom = new Geometry("Box", b);
        Material mat = new Material(am, "Common/MatDefs/Misc/Unshaded.j3md");
        this.am1=am;
        mat.setColor("Color", col);
        geom.setMaterial(mat);
     //   rootNode.attachChild(geom);
      
}
public void upd(float x,float y,float z,float x1,float y1,float z1){
  b.updateGeometry(new Vector3f(x, y, z), new Vector3f(x1, y1, z1));
}
public Geometry geo(){return this.geom;}
public Box bx(){return this.b;}
public void setColor(ColorRGBA col){
     Material mat = new Material(this.am1, "Common/MatDefs/Misc/Unshaded.j3md");
        mat.setColor("Color", col);
        geom.setMaterial(mat);
}
}
