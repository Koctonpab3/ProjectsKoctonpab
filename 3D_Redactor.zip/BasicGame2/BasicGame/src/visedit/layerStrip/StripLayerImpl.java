/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package visedit.layerStrip;

import intrerfaces.visedit.StripLayer;
import java.awt.Color;
import java.awt.Graphics;
import visedit.elements.ButtonImpl;

/**
 *
 * @author Admin
 */
public class StripLayerImpl implements StripLayer {
      int x,y,width,height,Enable,StCl;
      String[][][] Mas = new String[20][20][20];
      public ButtonImpl bckBtn = new ButtonImpl(0,0,0,0,"resources\\back.jpg","resources\\back.jpg");
      public ButtonImpl frwBtn = new ButtonImpl(0,0,0,0,"resources\\frwd.jpg","resources\\frwd.jpg");
      public SLcell cell1 = new SLcell(0,0,0,3);
      public SLcell cell2 = new SLcell(0,0,0,3);
      public SLcell cell3 = new SLcell(0,0,0,3);
      public SLcell cell4 = new SLcell(0,0,0,3);
   
   public StripLayerImpl(int x,int y,int w,int h){
   this.x=x;
   this.y=y;
   this.width=w;
   this.height=h;
   this.Enable=1;
   this.StCl=0;
   bckBtn.setX(this.x);
   frwBtn.setX(this.x+this.width-30);
   bckBtn.setY(this.y);
   frwBtn.setY(this.y);
   bckBtn.setWidth(30);
   frwBtn.setWidth(30);
   bckBtn.setHeight(this.height);
   frwBtn.setHeight(this.height);
   cell1.setX(this.x+40);
   cell1.setY(this.y+5);
   cell2.setX(this.x+110);
   cell2.setY(this.y+5);
   cell3.setX(this.x+180);
   cell3.setY(this.y+5);
   cell4.setX(this.x+250);
   cell4.setY(this.y+5);
   for(int i=0;i<20;i++)
        for(int j=0;j<20;j++)
        for(int z=0;z<20;z++){this.Mas[i][j][z]="000";}
   
   cell1.setMas(masToPar(this.Mas,this.StCl));
   cell2.setMas(masToPar(this.Mas,this.StCl+1));
   cell3.setMas(masToPar(this.Mas,this.StCl+2));
   cell4.setMas(masToPar(this.Mas,this.StCl+3));
   
   
   
   } 
 
     String[][] masToPar(String [][][] mas,int n){
       String[][]out = new String[20][20];
       for(int i=0;i<20;i++)
           for(int j=0;j<20;j++){
           out[i][j]=mas[i][j][n];
           }
       return out;
   }
   
   public void setPrjMini(String[][][] Mas){
for(int i=0;i<20;i++)
           for(int j=0;j<20;j++)
               for(int z=0;z<20;z++){
                   this.Mas[i][j][z]=Mas[i][j][z];
               }
}
   
  
   
   public void draw(Graphics g){
       g.clearRect(this.x, this.y, this.width, this.height);//очистка
       g.setColor(Color.white);//установка белого
       g.fillRect(this.x,this.y, this.width, this.height); //рисуем фон
       g.setColor(Color.DARK_GRAY); //установка серого
       g.drawRect(this.x,this.y, this.width, this.height);// рисуем окантовку}
       frwBtn.draw(g);
       bckBtn.draw(g);
       if (this.Enable==1){
       cell1.draw(g);
       cell2.draw(g);
       cell3.draw(g);
       cell4.draw(g);
       }
    }
    public void setCells(int s){
        cell1.setMas(masToPar(this.Mas,s));
        cell2.setMas(masToPar(this.Mas,s+1));
        cell3.setMas(masToPar(this.Mas,s+2));
      if ((s+3)<20) cell4.setMas(masToPar(this.Mas,s+3));
    }
    public int click(int x, int y) { 
        int outp=-1;
        if (x>=this.x & x<=(this.width+this.x) & y>=this.y & y<=(this.height+this.y) & this.Enable==1){
        if (frwBtn.click(x, y).equalsIgnoreCase("true")){
        if(this.StCl<16)this.StCl++;
        setCells(this.StCl);
        outp=this.StCl;
        //this.Enable=1;
        }
        if (bckBtn.click(x, y).equalsIgnoreCase("true")){
        if(this.StCl>0)this.StCl--;
        setCells(this.StCl);
        outp=this.StCl;
        //this.Enable=1;
        }
        if (!"false".equals(cell1.click(x, y))){
        outp=this.StCl;
        }
        if (!"false".equals(cell2.click(x, y))){
        outp=this.StCl+1;
        }
        if (!"false".equals(cell3.click(x, y))){
        outp=this.StCl+2;
        }
        if (!"false".equals(cell4.click(x, y))){
        outp=this.StCl+3;
        }
        }
        //outp="x:"+x+" y:"+y;
            return outp;}
    public void setX(int X) { this.x=X;}
    public void setY(int Y) { this.y=Y; 
    frwBtn.setY(Y);
    bckBtn.setY(Y);
    cell1.setY(Y+5);
    cell2.setY(Y+5);
    cell3.setY(Y+5);
    cell4.setY(Y+5);
    }
    public void setWl(int Y) { this.StCl=Y; }
    public int getWL() { return this.StCl; }
    public void setWidth(int W) {this.width=W; }
    public void setHeight(int H) {this.height=H; }
    public int getX() { return this.x; }
    public int getY() { return this.y; }
    public int getWidth(){return this.width; }
    public int getHeight(){return this.height;}  
    public void setEnable(int H) {this.Enable=H; }
    public int getEnable() { return this.Enable; }
    
}
