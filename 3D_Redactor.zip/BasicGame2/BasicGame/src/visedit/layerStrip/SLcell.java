/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package visedit.layerStrip;

import java.awt.Color;
import java.awt.Graphics;

/**
 *
 * @author Admin
 */
public class SLcell {
    int x,y, width,height,num,k;
    String[][] Mas = new String[20][20];
    
    public SLcell(int x, int y,int n,int k){
    this.k=k;
    this.num=n;
    this.x=x;this.y=y;this.num=n;
    this.height=this.width=20*k;
    for(int i=0;i<20;i++)
        for(int j=0;j<20;j++){this.Mas[i][j]="000";}//mas1[i][j];}
    }
    
    public int getN(){return this.num;}
    public int getWidth(){return this.width;}
    
    public void setN(int n){this.num=n;}
    
    public void setX(int n){this.x=n;}
    
    public void setY(int n){this.y=n;}
    
    public void setMas(String[][] in){
    for(int i=0;i<20;i++)
        for(int j=0;j<20;j++){this.Mas[i][j]=in[i][j];}
    }
    
    public String click(int x, int y) { 
        String outp="false";
        if (x>=this.x & x<=this.width+this.x & y>=this.y & y<=this.height+this.y )
        outp=""+this.num;
            return outp;}
           
        public void draw(Graphics g) {
g.clearRect(this.x, this.y, this.width, this.height);//очистка
g.setColor(Color.white);//установка белого
g.fillRect(this.x,this.y, this.width, this.height); //рисуем фон
g.setColor(Color.DARK_GRAY); //установка серого
g.drawRect(this.x,this.y, this.width, this.height);// рисуем окантовку}

for(int i=0;i<20;i++)
    for(int j=0;j<20;j++){
      
if (this.Mas[i][j].equalsIgnoreCase("000")) g.setColor(Color.black);//установка белого
if (this.Mas[i][j].equalsIgnoreCase("001")) g.setColor(Color.BLUE);
if (this.Mas[i][j].equalsIgnoreCase("010")) g.setColor(Color.GREEN);
if (this.Mas[i][j].equalsIgnoreCase("100")) g.setColor(Color.red);
if (this.Mas[i][j].equalsIgnoreCase("011")) g.setColor(Color.cyan);
if (this.Mas[i][j].equalsIgnoreCase("110")) g.setColor(Color.yellow);
if (this.Mas[i][j].equalsIgnoreCase("101")) g.setColor(Color.magenta);
if (this.Mas[i][j].equalsIgnoreCase("111")) g.setColor(Color.white);
g.fillRect(i*this.k+this.x,j*this.k+this.y, this.k, this.k);
    }
        
        }
    
    
}
